
# Jupyter Notebook Offline Install (Python 3.12)

Step 1: Open WinPython Command Prompt
Step 2: Navigate to this folder using `cd` command
Step 3: Run the following pip command:

    pip install *.whl

This will install Jupyter Notebook and all required dependencies.
